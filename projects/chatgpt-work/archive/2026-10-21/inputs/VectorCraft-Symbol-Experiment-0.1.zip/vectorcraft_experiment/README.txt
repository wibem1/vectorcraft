VectorCraft Symbol-Experiment 0.1 – Mac und Windows
=================================================
Zweck: Überprüfung der Live-Steuerung und Erkennung manueller Veränderungen.
Keine KI-Anbindung; keinerlei API-Kosten.

Voraussetzung: Python 3 mit tkinter, VectorCraft Desktop mit aktivem lokalen Steuerkanal.
VectorCraft MUSS mit --control 7979 gestartet werden (siehe offizielle Dokumentation).
Beispiele: vectorcraft --control 7979
macOS: ausführbare Datei innerhalb von VectorCraft.app entsprechend mit --control 7979 starten.
Windows: Verknüpfung auf VectorCraft.exe anlegen und im Feld Ziel hinter den Pfad --control 7979 einfügen.

Programm starten:
  Windows: py vectorcraft_experiment.py
  macOS:   python3 vectorcraft_experiment.py

Testablauf:
1. Dokument in VectorCraft erstellen und eine Form zeichnen und auswählen.
2. Verbindung prüfen. Bei Fehlermeldung VectorCraft mit --control 7979 neu starten.
3. „Symbol aus Auswahl“ klicken, dann „12 Instanzen“ (optional).
4. „Zustand merken“ drücken.
5. In VectorCraft MANUELL ein Objekt bzw. die Symboldefinition verändern.
6. Zurück zum Testfenster und „Änderungen prüfen“ wählen.
   Alternativ automatische Prüfung einschalten.
7. Ergebnisse aus dem Protokoll mitteilen.

Grenzen:
- „Änderungen prüfen“ erkennt zunächst nur, DASS Dokument, Symbolliste oder Auswahl anders ist.
  Objektweise Differenzanalyse, Konfliktbehandlung und echte Ereignisbenachrichtigung fehlen.
- Platzierung der zwölf Instanzen ohne Rotation: Dies ist ein Symboltest, kein fertiger Mandala-Generator.
- Es gibt keine Garantie, dass eine Änderung mitten in einem laufenden Einzelbefehl erkannt wird.
- Es erfolgt keine Verbindung zu OpenAI; Symbolanlage und Auslesbarkeit stehen im Vordergrund.
- Lokal laufender Kanal ohne Authentifizierung: nach dem Test VectorCraft normal neu starten.

Technische Grundlage: https://github.com/storytold/vectorcraft/blob/main/docs/control-protocol.md
