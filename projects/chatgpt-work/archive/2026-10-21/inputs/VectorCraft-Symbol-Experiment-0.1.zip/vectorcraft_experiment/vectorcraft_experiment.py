#!/usr/bin/env python3
"""VectorCraft symbol lab: stdlib-only control client; no AI API required."""
import json, socket, hashlib, math, threading, tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

HOST='127.0.0.1'; PORT=7979

class ControlError(Exception): pass

def call(method, params=None, timeout=12):
    request={'id':1,'method':method,'params':params or {}}
    try:
        with socket.create_connection((HOST, PORT), timeout=timeout) as s:
            s.settimeout(timeout)
            s.sendall((json.dumps(request,ensure_ascii=False)+'\n').encode('utf-8'))
            buf=b''
            while b'\n' not in buf:
                part=s.recv(65536)
                if not part: raise ControlError('Verbindung vor Antwort geschlossen')
                buf+=part
                if len(buf)>32*1024*1024: raise ControlError('Antwort zu groß')
            response=json.loads(buf.split(b'\n',1)[0])
    except (OSError, ValueError) as e: raise ControlError(str(e)) from e
    if not response.get('ok'): raise ControlError(str(response.get('error','Unbekannter Fehler')))
    return response.get('result')

def command(name, params=None):
    return call('engine.execute',{'command':name,'params':params or {}})

def canonical(obj): return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def digest(obj): return hashlib.sha256(canonical(obj).encode()).hexdigest()

class App:
    def __init__(self,root):
        self.root=root; root.title('VectorCraft Symbol-Experiment 0.1'); root.geometry('710x610')
        self.base=None; self.running=False; self.blocked=False
        outer=ttk.Frame(root,padding=12);outer.pack(fill='both',expand=True)
        ttk.Label(outer,text='VectorCraft · Symbole und manuelle Änderungen',font=('',13,'bold')).pack(anchor='w')
        ttk.Label(outer,text='Lokaler Test ohne KI und ohne API-Schlüssel. VectorCraft muss mit --control 7979 laufen.').pack(anchor='w',pady=(3,12))
        controls=ttk.Frame(outer);controls.pack(fill='x')
        for label,fn in [('Verbindung prüfen',self.check),('Zustand merken',self.snapshot),('Änderungen prüfen',self.diff),('Symbol aus Auswahl',self.new_symbol),('12 Instanzen',self.ring)]:
            ttk.Button(controls,text=label,command=fn).pack(side='left',padx=(0,5),pady=3)
        inputs=ttk.Frame(outer);inputs.pack(fill='x',pady=(8,4))
        ttk.Label(inputs,text='Symbolname:').pack(side='left');self.name=tk.StringVar(value='Mandala-Blatt');ttk.Entry(inputs,textvariable=self.name,width=20).pack(side='left',padx=6)
        ttk.Label(inputs,text='Zentrum X/Y:').pack(side='left');self.cx=tk.StringVar(value='400');self.cy=tk.StringVar(value='400')
        ttk.Entry(inputs,textvariable=self.cx,width=6).pack(side='left');ttk.Entry(inputs,textvariable=self.cy,width=6).pack(side='left',padx=(3,6))
        ttk.Label(inputs,text='Radius:').pack(side='left');self.radius=tk.StringVar(value='160');ttk.Entry(inputs,textvariable=self.radius,width=7).pack(side='left',padx=3)
        self.auto=tk.BooleanVar(value=False)
        ttk.Checkbutton(outer,text='Zustandsvergleich automatisch alle 2 Sekunden (nur lesen)',variable=self.auto).pack(anchor='w',pady=7)
        ttk.Label(outer,text='Protokoll:').pack(anchor='w')
        self.logbox=scrolledtext.ScrolledText(outer,height=24,wrap='word');self.logbox.pack(fill='both',expand=True)
        ttk.Label(outer,text='Hinweis: Instanzen werden hier nur platziert, nicht radial gedreht. Symbol- und Änderungsprüfung zuerst.',foreground='#555').pack(anchor='w',pady=(7,0))
        root.after(2000,self.tick)
    def log(self,msg):
        self.logbox.insert('end',msg+'\n');self.logbox.see('end')
    def work(self,label,fn):
        if self.running: return
        self.running=True
        def bg():
            try: result=fn(); self.root.after(0,lambda:self.log('✓ '+label+': '+str(result)))
            except Exception as e:self.root.after(0,lambda:self.log('✗ '+label+': '+str(e)))
            finally:self.root.after(0,lambda:setattr(self,'running',False))
        threading.Thread(target=bg,daemon=True).start()
    def check(self):self.work('Verbindung',lambda: {'ui':str(call('ui.inspect'))[:230], 'symbole':command('symbol.list')})
    def get_state(self):return {'document':command('document.json'), 'symbols':command('symbol.list'), 'selection':call('document.inspect',{'depth':0}) .get('selection') if isinstance(call('document.inspect',{'depth':0}),dict) else None}
    def snapshot(self):
        def f():
            self.base=self.get_state(); return 'Referenz gespeichert (SHA256 '+digest(self.base)[:12]+')'
        self.work('Zustand merken',f)
    def diff(self):
        def f():
            if self.base is None: raise ControlError('Zuerst „Zustand merken“ drücken')
            now=self.get_state();changes=[key for key in now if digest(now[key])!=digest(self.base[key])]
            self.base=now
            return 'Unterschiede in '+', '.join(changes) if changes else 'Keine Unterschiede seit der letzten Messung'
        self.work('Änderungen prüfen',f)
    def new_symbol(self):
        def f():
            n=self.name.get().strip()
            if not n: raise ControlError('Symbolname fehlt')
            before=command('symbol.list');created=command('symbol.new',{'name':n});after=command('symbol.list')
            return {'angelegt':created,'symbol_liste_vorher':str(before)[:150],'symbol_liste_nachher':str(after)[:300]}
        self.work('Symbol aus Auswahl',f)
    def ring(self):
        def f():
            name=self.name.get().strip()
            try:cx=float(self.cx.get());cy=float(self.cy.get());r=float(self.radius.get())
            except ValueError:raise ControlError('X, Y und Radius müssen Zahlen sein')
            if not all(map(math.isfinite,[cx,cy,r])) or r<=0:raise ControlError('Ungültige Maße')
            if not messagebox.askyesno('12 Instanzen','Jetzt zwölf Symbolinstanzen erzeugen? Vorher Dokument sichern.'):return 'Abgebrochen'
            completed=0
            for j in range(12):
                a=2*math.pi*j/12
                command('symbol.place',{'name':name,'x':round(cx+r*math.cos(a),4),'y':round(cy+r*math.sin(a),4)})
                completed+=1
            return f'{completed} Instanzen platziert (noch ohne Drehung)'
        # Dialog auf UI-Thread, Befehle im Hintergrund
        try:
            name=self.name.get().strip();cx=float(self.cx.get());cy=float(self.cy.get());r=float(self.radius.get())
            if not name or not all(map(math.isfinite,[cx,cy,r])) or r<=0:raise ValueError()
        except ValueError:self.log('✗ Ungültiger Symbolname oder Maße');return
        if not messagebox.askyesno('12 Instanzen','Jetzt zwölf Symbolinstanzen erzeugen? Dokument vorher sichern.'):return
        def send():
            for j in range(12):
                a=2*math.pi*j/12
                command('symbol.place',{'name':name,'x':round(cx+r*math.cos(a),4),'y':round(cy+r*math.sin(a),4)})
            return '12 Instanzen platziert (ohne Drehung)'
        self.work('12 Instanzen',send)
    def tick(self):
        if self.auto.get() and self.base is not None and not self.running:self.diff()
        self.root.after(2000,self.tick)

if __name__=='__main__':
    root=tk.Tk();App(root);root.mainloop()
