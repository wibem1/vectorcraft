VECTORCRAFT SYMBOL-EXPERIMENT 0.2 – WINDOWS UND MAC
=================================================

Voraussetzungen: Python 3 mit tkinter, VectorCraft Desktop mit aktivem Steuerkanal.
Windows-Start (bei Standardinstallation):
"C:\Program Files\VectorCraft\vectorcraft.exe" --control 7979
Mac (VectorCraft vorher beenden):
open -a VectorCraft --args --control 7979

Start der Testanwendung unter Windows:
Im entpackten Ordner die Explorer-Adresszeile anklicken, cmd eingeben,
dann: py vectorcraft_experiment.py
Mac: python3 vectorcraft_experiment.py

TEST 1 – MANUELLE OBJEKTÄNDERUNG
1. VectorCraft öffnen und ein Dokument mit einer Form vorbereiten.
2. Im Experiment 'Verbindung', dann 'Referenz speichern' anklicken.
3. Eine Form im VectorCraft-Fenster von Hand verschieben.
4. 'Änderungen prüfen' anklicken.
5. Im Protokoll erscheinen JSON-Pfade und alte/neue Daten.

TEST 2 – SYMBOLDEFINITION
1. Form auswählen, 'Symbol aus Auswahl' anklicken.
2. '12 Instanzen' erzeugen und 'Referenz speichern' anklicken.
3. In VectorCraft die Symboldefinition manuell verändern.
4. 'Änderungen prüfen' anklicken. Symbol- und Dokument-Diff vergleichen.
5. Optional 'Bericht exportieren' und JSON bereitstellen.

TEST 3 – EINZELNE INSTANZ
1. Wieder 'Referenz speichern'.
2. Eine Instanz manuell verschieben.
3. 'Änderungen prüfen': im Dokument-Diff sollte eine Änderung sichtbar sein.

AUTOMATIK
Die Checkbox führt alle 2 Sekunden reine Lese-Abfragen aus. Der zuletzt
ausgelesene Stand wird danach jeweils zur neuen Referenz. Vor längeren
Bearbeitungen Automatik ausschalten, damit Änderungen nicht zwischen zwei
Messungen verschwinden.

WICHTIGE EINSCHRÄNKUNGEN
- Kein KI-Zugriff, kein API-Schlüssel, keine Cloud.
- Symboloperationen werden nur nach Buttonklick gestartet.
- Prüfungen sind strukturelle JSON-Vergleiche, noch keine zuverlässige
  Zuordnung bei Umordnung von Listen oder Neuvergabe von Objekt-IDs.
- Mehrere nacheinander ausgeführte manuelle Schritte zwischen zwei Messungen
  sind als Endzustand sichtbar, nicht als einzelne Gesten.
- Dokument- und Symboldaten werden in getrennten Abfragen gelesen; die
  Momentaufnahme ist nicht atomar.
- Große Änderungen werden in der Protokollansicht gekürzt und pro Kategorie
  auf 120 Einträge begrenzt. Dies ist ein diagnostischer Prototyp.
- Vor schreibenden Tests Datei speichern. --control 7979 nach Benutzung
  durch Beenden und normalen Neustart von VectorCraft deaktivieren.
