@echo off
cd /d "%~dp0"
py -3 vectorcraft_mandala_zentriert.py --check-only
pause
