#!/usr/bin/env python3
"""VectorCraft native live-repeat mandala. Standard-library only; no AI calls.

Start VectorCraft with --control 7979. This script makes a NEW document, then
constructs three editable radial Repeat objects from Bezier ornament motifs.
It does not automatically save, preserving the option to inspect the result.
"""
import argparse
import json
import math
import socket
import sys
import time
from datetime import datetime
from pathlib import Path

COMMANDS = ["file.new", "path.create", "paint.setFill", "paint.setStroke", "stroke.set",
            "object.repeat.radial", "object.repeat.options", "select.set"]

class VC:
    def __init__(self, host, port):
        self.sock = socket.create_connection((host, port), timeout=8)
        self.sock.settimeout(30)
        self.buffer = b""
        self.seq = 0
        self.trace = []
    def call(self, method, params=None):
        self.seq += 1
        payload = {"id": self.seq, "method": method, "params": params or {}}
        self.sock.sendall((json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8"))
        while b"\n" not in self.buffer:
            chunk = self.sock.recv(262144)
            if not chunk:
                raise RuntimeError("VectorCraft hat die Verbindung geschlossen")
            self.buffer += chunk
            if len(self.buffer) > 30_000_000:
                raise RuntimeError("Antwort zu groß")
        line, self.buffer = self.buffer.split(b"\n", 1)
        obj = json.loads(line.decode("utf-8"))
        if obj.get("error"):
            raise RuntimeError(f"{method}: {obj['error']}")
        return obj.get("result", obj)
    def exec(self, command, params=None):
        result = self.call("engine.execute", {"command": command, "params": params or {}})
        self.trace.append({"command": command, "params": params, "result": result})
        if isinstance(result, dict) and (result.get("error") or result.get("ok") is False):
            raise RuntimeError(f"{command}: {result}")
        return result
    def close(self): self.sock.close()

def has_command(tree, name):
    if isinstance(tree, dict):
        if name in [tree.get("id"), tree.get("name"), tree.get("command")]:
            return True
        return name in tree or any(has_command(v, name) for v in tree.values())
    if isinstance(tree, list): return any(has_command(x,name) for x in tree)
    return tree == name if isinstance(tree, str) else False

def result_id(res):
    if isinstance(res,dict):
        if "id" in res and isinstance(res["id"],(str,int)):return res["id"]
        if isinstance(res.get("result"),dict):return result_id(res["result"])
    raise RuntimeError(f"Kein Objekt-ID in Antwort: {str(res)[:500]}")

def rotate_xy(x, y, angle, cx=700, cy=700):
    t=math.radians(angle); dx=x-cx; dy=y-cy
    return (cx + dx*math.cos(t)-dy*math.sin(t),cy + dx*math.sin(t)+dy*math.cos(t))

def transform_svg_d(d, angle):
    """Only supports the handcrafted M,C,L,Z path grammar in this script."""
    import re
    tokens=re.findall(r'[MCLZ]|-?\d+(?:\.\d+)?',d)
    out=[];i=0
    while i<len(tokens):
        op=tokens[i];i+=1;out.append(op)
        if op=='Z':continue
        n={'M':1,'L':1,'C':3}[op]
        for _ in range(n):
            x=float(tokens[i]);y=float(tokens[i+1]);i+=2
            xx,yy=rotate_xy(x,y,angle)
            out.append(f'{xx:.3f} {yy:.3f}')
    return ' '.join(out)

# The forms are original bespoke scrollwork shapes, NOT raster tracing.
MOTIFS = [
    dict(name="Äußerer Arabeskenkranz", count=12, radius=340, color="#0c6571", outline="#1d3441", line=5,
         paths=[
             "M 700 187 C 727 201 741 228 733 254 C 725 279 701 290 677 281 C 658 273 649 252 659 235 C 668 220 682 220 690 232",
             "M 700 187 C 673 201 659 228 667 254 C 675 279 699 290 723 281 C 742 273 751 252 741 235 C 732 220 718 220 710 232",
             "M 700 206 C 715 232 719 263 700 294 C 681 263 685 232 700 206 Z",
         ]),
    dict(name="Mittlerer Knotenring", count=8, radius=230, color="#c68c79", outline="#263946", line=6,
         paths=[
             "M 700 295 C 750 321 778 365 762 404 C 748 440 714 458 700 487 C 686 458 652 440 638 404 C 622 365 650 321 700 295 Z",
             "M 700 325 C 727 348 738 372 729 395 C 723 415 708 431 700 449 C 692 431 677 415 671 395 C 662 372 673 348 700 325 Z",
             "M 668 367 C 682 354 718 354 732 367",
         ]),
    dict(name="Innerer Blütenstern", count=8, radius=112, color="#d5af65", outline="#253f4b", line=4,
         paths=[
             "M 700 465 C 727 479 744 503 738 530 C 734 549 713 570 700 584 C 687 570 666 549 662 530 C 656 503 673 479 700 465 Z",
             "M 700 484 C 711 508 710 541 700 558 C 690 541 689 508 700 484 Z",
         ]),
]

def shift_motif_y(d, delta):
    """Shift all coordinate pairs in our M/C/L-only SVG paths vertically."""
    import re
    parts = re.findall(r"[MCLZ]|-?\d+(?:\.\d+)?", d)
    converted=[]
    i=0
    while i<len(parts):
        op=parts[i];i+=1
        converted.append(op)
        if op=="Z": continue
        for _ in range({"M":1,"L":1,"C":3}[op]):
            x=float(parts[i]);y=float(parts[i+1]);i+=2
            converted.append(f"{x:g} {y+delta:.3f}")
    return " ".join(converted)

# midpoints of Y extent of each reference motif, from the hand-authored paths.
# shift source motif to be centered at (700, 700-radius) prior to repetition.
SOURCE_Y_MIDPOINTS = [240.5, 391.0, 524.5]

def new_path(vc,d,fill,stroke,width):
    res=vc.exec('path.create',{'d':d})
    oid=result_id(res)
    vc.exec('paint.setFill',{'ids':[oid], 'color':fill}) if fill else vc.exec('paint.setFill',{'ids':[oid],'none':True})
    vc.exec('paint.setStroke',{'ids':[oid],'color':stroke})
    vc.exec('stroke.set',{'ids':[oid],'weight':width,'join':'round','cap':'round'})
    return oid

def build(vc):
    vc.exec('file.new',{'width':1400,'height':1400})
    # Cream background, separately created as native vector object.
    bg=vc.exec('shape.rectangle',{'x':0,'y':0,'width':1400,'height':1400})
    bg_id=result_id(bg)
    vc.exec('paint.setFill',{'ids':[bg_id],'color':'#f3ead9'})
    vc.exec('paint.setStroke',{'ids':[bg_id],'none':True})
    repeats=[]
    for ring_index, motif in enumerate(MOTIFS):
        ids=[]
        # a single motif contains several paths. IDs go to Repeat atomically.
        for idx,d in enumerate(motif['paths']):
            is_main=(idx==0)
            ids.append(new_path(vc,shift_motif_y(d, (700-motif['radius'])-SOURCE_Y_MIDPOINTS[ring_index]),motif['color'] if is_main else None,
                                motif['outline'] if is_main else '#f4dba6',
                                motif['line'] if is_main else 3.0))
        rep=vc.exec('object.repeat.radial',{'ids':ids,'instances':motif['count'],'radius':motif['radius']})
        rid=result_id(rep)
        # The default Repeat center is derived from bounds + radius, and can
        # differ between rings. Set an explicit, shared center for every ring.
        vc.exec('select.set',{'ids':[rid]})
        vc.exec('object.repeat.options',{'center':[700,700],
                                        'instances':motif['count'],
                                        'radius':motif['radius']})
        repeats.append({'ring':motif['name'],'id':rid,'instances':motif['count']})
        print(f"  {motif['name']}: {motif['count']} Wiederholungen, Objekt {rid}")
    # core remains a native editable ellipse
    center=vc.exec('shape.ellipse',{'x':655,'y':655,'width':90,'height':90})
    center_id=result_id(center)
    vc.exec('paint.setFill',{'ids':[center_id],'color':'#f1d28a'})
    vc.exec('paint.setStroke',{'ids':[center_id],'color':'#243f4b'})
    vc.exec('stroke.set',{'ids':[center_id],'weight':5})
    return repeats

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--port',type=int,default=7979)
    p.add_argument('--host',default='127.0.0.1')
    p.add_argument('--check-only',action='store_true')
    args=p.parse_args()
    vc=None
    status={'time':datetime.now().isoformat(),'mode':'check' if args.check_only else 'build'}
    try:
        vc=VC(args.host,args.port)
        commands=vc.call('engine.commands')
        required=COMMANDS+['shape.ellipse','shape.rectangle']
        missing=[cmd for cmd in required if not has_command(commands,cmd)]
        status['missing_commands']=missing
        if missing: raise RuntimeError('Nicht im Befehlskatalog: '+', '.join(missing))
        print('VectorCraft-Steuerung: alle benötigten Befehle gefunden.')
        if args.check_only:
            print('Keine Änderungen vorgenommen. Jetzt kann das Mandala erzeugt werden.')
            return 0
        print('Konstruiere drei native Ornamentringe...')
        status['repeats']=build(vc)
        print('Fertig. Bitte prüfen und anschließend manuell als .vectorcraft speichern.')
        return 0
    except Exception as exc:
        status['error']=str(exc)
        print('FEHLER:',exc)
        return 1
    finally:
        if vc:
            status['trace']=vc.trace
            vc.close()
        target=Path(__file__).with_name('mandala_diagnose_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.json')
        target.write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
        print('Diagnose:',target.name)

if __name__=='__main__':sys.exit(main())
